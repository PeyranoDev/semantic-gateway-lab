""" THIS IS AN AUTOMATICALLY GENERATED FILE!"""
from __future__ import print_function
import json
from engine import primitives
from engine.core import requests
from engine.errors import ResponseParsingException
from engine import dependencies
req_collection = requests.RequestCollection([])
# Endpoint: /bookings, method: Get
request = requests.Request([
    primitives.restler_static_string("GET "),
    primitives.restler_basepath(""),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("bookings"),
    primitives.restler_static_string(" HTTP/1.1\r\n"),
    primitives.restler_static_string("Accept: application/json\r\n"),
    primitives.restler_static_string("Host: 127.0.0.1:8765\r\n"),
    primitives.restler_static_string("authorization: "),
    primitives.restler_custom_payload_header("authorization"),
    primitives.restler_static_string("\r\n"),
    primitives.restler_refreshable_authentication_token("authentication_token_tag"),
    primitives.restler_static_string("\r\n"),

],
requestId="/bookings"
)
req_collection.add_request(request)

# Endpoint: /bookings/{identifier}, method: Get
request = requests.Request([
    primitives.restler_static_string("GET "),
    primitives.restler_basepath(""),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("bookings"),
    primitives.restler_static_string("/"),
    primitives.restler_custom_payload("identifier", quoted=False),
    primitives.restler_static_string(" HTTP/1.1\r\n"),
    primitives.restler_static_string("Accept: application/json\r\n"),
    primitives.restler_static_string("Host: 127.0.0.1:8765\r\n"),
    primitives.restler_static_string("authorization: "),
    primitives.restler_custom_payload_header("authorization"),
    primitives.restler_static_string("\r\n"),
    primitives.restler_refreshable_authentication_token("authentication_token_tag"),
    primitives.restler_static_string("\r\n"),

],
requestId="/bookings/{identifier}"
)
req_collection.add_request(request)

# Endpoint: /bookings/{identifier}/reserve, method: Post
request = requests.Request([
    primitives.restler_static_string("POST "),
    primitives.restler_basepath(""),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("bookings"),
    primitives.restler_static_string("/"),
    primitives.restler_custom_payload("identifier", quoted=False),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("reserve"),
    primitives.restler_static_string(" HTTP/1.1\r\n"),
    primitives.restler_static_string("Accept: application/json\r\n"),
    primitives.restler_static_string("Host: 127.0.0.1:8765\r\n"),
    primitives.restler_static_string("authorization: "),
    primitives.restler_custom_payload_header("authorization"),
    primitives.restler_static_string("\r\n"),
    primitives.restler_refreshable_authentication_token("authentication_token_tag"),
    primitives.restler_static_string("\r\n"),

],
requestId="/bookings/{identifier}/reserve"
)
req_collection.add_request(request)

# Endpoint: /bookings/{identifier}/pay, method: Post
request = requests.Request([
    primitives.restler_static_string("POST "),
    primitives.restler_basepath(""),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("bookings"),
    primitives.restler_static_string("/"),
    primitives.restler_custom_payload("identifier", quoted=False),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("pay"),
    primitives.restler_static_string(" HTTP/1.1\r\n"),
    primitives.restler_static_string("Accept: application/json\r\n"),
    primitives.restler_static_string("Host: 127.0.0.1:8765\r\n"),
    primitives.restler_static_string("authorization: "),
    primitives.restler_custom_payload_header("authorization"),
    primitives.restler_static_string("\r\n"),
    primitives.restler_refreshable_authentication_token("authentication_token_tag"),
    primitives.restler_static_string("\r\n"),

],
requestId="/bookings/{identifier}/pay"
)
req_collection.add_request(request)

# Endpoint: /bookings/{identifier}/confirm, method: Post
request = requests.Request([
    primitives.restler_static_string("POST "),
    primitives.restler_basepath(""),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("bookings"),
    primitives.restler_static_string("/"),
    primitives.restler_custom_payload("identifier", quoted=False),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("confirm"),
    primitives.restler_static_string(" HTTP/1.1\r\n"),
    primitives.restler_static_string("Accept: application/json\r\n"),
    primitives.restler_static_string("Host: 127.0.0.1:8765\r\n"),
    primitives.restler_static_string("authorization: "),
    primitives.restler_custom_payload_header("authorization"),
    primitives.restler_static_string("\r\n"),
    primitives.restler_refreshable_authentication_token("authentication_token_tag"),
    primitives.restler_static_string("\r\n"),

],
requestId="/bookings/{identifier}/confirm"
)
req_collection.add_request(request)

# Endpoint: /bookings/{identifier}/cancel, method: Post
request = requests.Request([
    primitives.restler_static_string("POST "),
    primitives.restler_basepath(""),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("bookings"),
    primitives.restler_static_string("/"),
    primitives.restler_custom_payload("identifier", quoted=False),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("cancel"),
    primitives.restler_static_string(" HTTP/1.1\r\n"),
    primitives.restler_static_string("Accept: application/json\r\n"),
    primitives.restler_static_string("Host: 127.0.0.1:8765\r\n"),
    primitives.restler_static_string("authorization: "),
    primitives.restler_custom_payload_header("authorization"),
    primitives.restler_static_string("\r\n"),
    primitives.restler_refreshable_authentication_token("authentication_token_tag"),
    primitives.restler_static_string("\r\n"),

],
requestId="/bookings/{identifier}/cancel"
)
req_collection.add_request(request)

# Endpoint: /bookings/{identifier}/refund, method: Post
request = requests.Request([
    primitives.restler_static_string("POST "),
    primitives.restler_basepath(""),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("bookings"),
    primitives.restler_static_string("/"),
    primitives.restler_custom_payload("identifier", quoted=False),
    primitives.restler_static_string("/"),
    primitives.restler_static_string("refund"),
    primitives.restler_static_string(" HTTP/1.1\r\n"),
    primitives.restler_static_string("Accept: application/json\r\n"),
    primitives.restler_static_string("Host: 127.0.0.1:8765\r\n"),
    primitives.restler_static_string("authorization: "),
    primitives.restler_custom_payload_header("authorization"),
    primitives.restler_static_string("\r\n"),
    primitives.restler_refreshable_authentication_token("authentication_token_tag"),
    primitives.restler_static_string("\r\n"),

],
requestId="/bookings/{identifier}/refund"
)
req_collection.add_request(request)
